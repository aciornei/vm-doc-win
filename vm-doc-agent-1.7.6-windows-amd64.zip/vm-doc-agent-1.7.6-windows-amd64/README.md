# vm-doc-agent 1.7.6

## Versiunea 1.7.6

1.7.6 repară inventarul software Windows pe sisteme lente: collectorul `software` are minimum 60s, iar Registry, AppX/MSIX și Windows Features rulează independent. Dacă o sursă secundară expiră, datele deja obținute rămân în inventar și collectorul este `partial`, nu `error`. Include și compatibilizarea Task Scheduler din 1.7.5 pentru rularea sub SYSTEM fără `LogonType=ServiceAccount`. Schema inventarului rămâne 2.9.

## Versiunea 1.7.4

Versiunea 1.7.4 elimină dependența de PowerShell pentru instalarea Windows. `vm-doc-agent.exe` include acum comenzile native `install`, `repair`, `status` și `uninstall`; instalarea folosește Task Scheduler, `netsh` și `icacls` direct, rulează agentul sub `SYSTEM` și nu necesită `Set-ExecutionPolicy`. Binarele sunt instalate în `C:\Program Files\VM-Doc\Agent`, iar starea/configurația rămân în `C:\ProgramData\VM-Doc\Agent`. Este inclusă și definiția MSI x64 pentru deployment enterprise; schema inventarului rămâne 2.9 și serverul minim rămâne 0.19.16.

Exemplu de instalare dintr-un Command Prompt/PowerShell elevat, fără rularea vreunui script PowerShell:

```text
vm-doc-agent.exe install --central-url http://172.20.1.20:9080
```

Pentru deployment neinteractiv se recomandă tokenul într-un fișier ACL-protejat:

```text
vm-doc-agent.exe install --central-url http://172.20.1.20:9080 --registration-token-file C:\Secure\vm-doc-registration-token.txt --firewall-remote 172.20.0.0/16 --quiet
```

## Versiunea 1.7.3

Versiunea 1.7.3 repară collectorul `software` pe Windows PowerShell 5.1. Listele generice folosite pentru aplicații și avertismente sunt convertite explicit la array înainte de serializarea JSON, iar valorile returnate de `List.Add()` sunt suprimate. Astfel collectorul nu mai eșuează cu `Argument types do not match` și nu mai poate polua ieșirea JSON cu indecșii returnați de `Add()`. Schema inventarului rămâne 2.9.

## Versiunea 1.7.2

Versiunea 1.7.2 adaugă inventarul complet de software instalat pe Windows. Collectorul citește cheile Uninstall x64/x86, aplicațiile per-user din hive-urile încărcate, pachetele AppX/MSIX și Windows Features/Roles. `Win32_Product` nu este folosit. Datele sunt raportate în `software.items`; selecția aplicațiilor principale pentru documentație este realizată de vm-doc-server 0.19.16+.


## Versiunea 1.7.1

1.7.1 repară reinstalarea Windows atunci când un config parțial are `central.enabled=true` dar URL invalid și adaugă discovery Microsoft SQL Server fără parolă. Instanțele MSSQL sunt detectate din Registry/Windows Services, iar agentul folosește autentificare Windows integrată (`SSPI`) prin ADO.NET sub contul `SYSTEM`, colectând versiunea, ediția și numele bazelor vizibile. `master`, `model`, `msdb` și `tempdb` sunt marcate ca baze de sistem și nu apar în UI/fișe pe vm-doc-server 0.19.15+. Schema rămâne 2.8.

## Versiunea 1.7.0

1.7.0 introduce agentul Windows x64 pe aceeași bază de protocol și auto-update ca agentul Linux. Windows Server 2016+ și Windows 10/11 folosesc același binar Go; în 1.7.4 instalarea este nativă, fără PowerShell obligatoriu, iar agentul rulează ca Scheduled Task sub SYSTEM și publică același inventar schema 2.8 către vm-doc-server. Linux rămâne compatibil și păstrează toate funcțiile din 1.6.11.


## Versiunea 1.6.11

Versiunea 1.6.11 întărește discovery-ul PostgreSQL pe hosturi vechi și multi-instancă. Recunoaște și procesul `postmaster`, corelează socketurile Unix deținute efectiv de proces prin `/proc`, preferă portul/socketul instanței înaintea valorilor implicite și păstrează fallbackurile locale fără parolă. Astfel PostgreSQL 8/9 pot fi inventariate corect în paralel pe același host. Schema rămâne 2.7.

## Versiunea 1.6.10

Versiunea 1.6.10 extinde compatibilitatea bazelor de date pe distribuții și instalații vechi. Schimbarea de user folosește `runuser` când există și cade pe `su -s /bin/sh -c` pe SUSE/SLES 11. PostgreSQL este interogat per instanță, cu port/socket și client `psql` corespunzător, iar baza tehnică este aleasă `postgres` → `template1`. Collectorul cron încearcă și `crontab -u postgres -l`, iar inventarul DB poate raporta joburi `pgAgent`/`pg_cron` numai ca metadata, fără SQL/script/comandă. Schema devine 2.7.

## Versiunea 1.6.9

Versiunea 1.6.9 extinde modelul local fără parolă și la PostgreSQL. Dacă există userul Linux `vm-doc-inventory`, agentul rulează `psql` prin `runuser -u vm-doc-inventory`, folosește rolul PostgreSQL cu același nume și forțează `-w` (fără prompt de parolă). Dacă userul dedicat există dar autentificarea `peer` sau dreptul CONNECT nu este configurat corect, agentul nu face fallback la userul `postgres`. Dacă userul dedicat nu există, comportamentul legacy prin userul OS `postgres` rămâne disponibil. Schema inventarului rămâne 2.6.

## Versiunea 1.6.8

Versiunea 1.6.8 adaugă suport oficial pentru Linux x86 pe 32 de biți (`GOARCH=386`) pe lângă `amd64`. Pachetele per-arhitectură refuză instalarea dacă nu corespund hostului, iar pachetul `linux-multiarch` detectează automat `x86_64/amd64` sau `i386/i486/i586/i686` și selectează binarele potrivite. Buildul 386 este static (`CGO_ENABLED=0`) și folosește `GO386=softfloat`, pentru compatibilitate mai bună cu servere vechi precum Debian 7. Schema inventarului rămâne 2.6.

## Versiunea 1.6.7

Versiunea 1.6.7 clasifică serviciile observate ca `system`, `application` sau `unknown`. Clasificarea este conservatoare: produsele/middleware cunoscute și unitățile systemd locale sunt marcate ca aplicație, serviciile și pachetele OS cunoscute ca sistem, iar cazurile incerte rămân `unknown`. Inventarul brut păstrează toate serviciile; filtrarea este responsabilitatea serverului 0.19.12+.

## Versiunea 1.6.6

Versiunea 1.6.6 adaugă discovery MySQL/MariaDB fără parolă printr-un user OS dedicat. Dacă există `vm-doc-inventory`, agentul (care poate rula în continuare ca root) execută clientul `mysql`/`mariadb` prin `runuser -u vm-doc-inventory`, forțează protocolul socket și folosește userul DB cu același nume. Dacă userul dedicat nu există, comportamentul legacy rămâne disponibil pentru compatibilitate.

Configurația recomandată pe MariaDB este un user DB `vm-doc-inventory@localhost` autentificat prin `unix_socket` și cu privilegiul global minim `SHOW DATABASES`. Agentul nu stochează și nu transmite parole.

## Versiunea 1.6.5

Versiunea 1.6.5 adaugă un motiv structurat și secret-safe atunci când enumerarea locală a bazelor nu poate fi realizată. Pentru PostgreSQL, MySQL/MariaDB și MongoDB, `catalog_discovery_reason` poate indica `authentication_required`, `permission_denied`, `socket_unavailable`, `server_unavailable`, `client_not_found`, `timeout`, `os_user_unavailable`, `query_failed` sau `unsupported_engine`. Agentul nu transmite stderr brut, parole sau connection strings.

## Versiunea 1.6.4

Versiunea 1.6.4 îmbunătățește inventarul Web pentru Apache HTTP Server. Agentul pornește din configurația principală detectată din proces sau din `httpd/apache2 -V` și urmărește recursiv directivele `Include` și `IncludeOptional`. Astfel sunt găsite automat VirtualHost-urile din directoare precum `/etc/httpd/vhosts.d`, `/etc/httpd/conf.d`, `/etc/apache2/sites-enabled` sau orice altă cale inclusă din configurația Apache.

## Versiunea 1.6.3


Versiunea 1.6.3 adaugă colectorul `hosts`, care parsează `/etc/hosts` și raportează numai mapările utile `IP -> nume/aliasuri`. Este destinat în special serverelor Prometheus, astfel încât vm-doc-server să poată corela targeturile definite prin aliasuri locale cu VM-urile reale după IP. Sunt ignorate adresele loopback, comentariile, liniile invalide și duplicatele.

Exemplu: dacă `hostname` este `kestra`, iar DNS are `kestra.xxx.ro CNAME nginx.xxx.ro`, inventarul va conține `hostname=kestra`, `fqdn=kestra.xxx.ro` și `canonical_dns_name=nginx.xxx.ro`.

## Versiunea 1.6.1

Versiunea 1.6.1 îmbunătățește collectorul Web pentru instalări Nginx non-standard. Agentul pornește de la executabilul procesului, citește `-p` / `-c`, folosește `nginx -V` pentru `--prefix` și `--conf-path` și urmărește recursiv directivele `include`, inclusiv atunci când Nginx este instalat sub `/opt`.

## Versiunea 1.6.0

Versiunea 1.6.0 adaugă inventarul host-level pentru Nginx, Apache HTTP Server și HAProxy. Agentul detectează serverele instalate/rulate și extrage metadate sigure despre site-uri, virtual hosts și frontends: nume publice, bind-uri/porturi, document root, backend-uri și ținte proxy, fără a trimite conținutul brut al configurațiilor, credențiale, chei private sau valori de headere. Tot în 1.6.0 este corectată starea PostgreSQL: un proces `postgres` care rulează nu mai poate fi marcat `inactive` doar pentru că unitatea generică `postgresql.service` este inactivă; este preferată unitatea activă a clusterului, de exemplu `postgresql@16-main.service`.

## Versiunea 1.5.0

Versiunea 1.5.0 adaugă collectorul `databases` pentru PostgreSQL, MySQL, MariaDB, MongoDB, Oracle Database, Microsoft SQL Server, IBM Db2, Redis, Firebird și CockroachDB. Sunt colectate numai metadate de inventar (engine, versiune, instanță, endpoint, directoare/config cunoscute și, best-effort, numele bazelor logice). Nu sunt colectate parole, connection strings, query-uri sau date din baze. Pe hosturile DB partajate, serverul poate asocia separat fiecare instanță sau bază logică unui alt serviciu intern.

## Versiunea 1.4.1

Versiunea 1.4.1 repară actualizarea configurației la upgrade. Valorile existente din `/etc/vm-doc-agent/config.json` sunt păstrate, iar cheile introduse de versiunea nouă sunt adăugate automat. Auto-updaterul păstrează și `/etc/vm-doc-agent/config.json.previous` și face rollback atât la binar, cât și la configurație dacă migrarea sau health-check-ul eșuează.

Comanda poate fi rulată și manual:

```bash
/usr/local/sbin/vm-doc-agent -config /etc/vm-doc-agent/config.json -migrate-config
```

## Versiunea 1.4.0

Versiunea 1.4.0 adaugă inventarierea Docker structurată: engine, containere, Docker Compose, imagini, rețele și volume. Colectorul nu salvează valorile variabilelor de mediu, secrete, loguri sau conținutul fișierelor montate. Pentru asociere automată cu servicii, serverul poate folosi labels `vm-doc.service`, `vm-doc.services`, `vm-doc.component` și `vm-doc.role`.


Agentul și updaterul scriu acum propriul log persistent în `/var/log/vm-doc-agent.log`, independent de systemd/journald sau syslog. Pe sistemele cu systemd logarea rămâne și în journal. Pe instalările SysV existente este detectată redirecționarea către același fișier pentru a evita dublarea liniilor. Configurația logrotate existentă continuă să fie folosită.

## Ce aduce versiunea 1.3.4

- repară auto-update-ul pe CentOS 7 / systemd 219;
- detectează capabilitățile reale ale `systemd-run` înainte de a folosi `--collect` și `--no-block`;
- nu mai forțează `Type=exec`, incompatibil cu unele versiuni systemd vechi;
- păstrează helperul de update într-o unitate systemd separată și păstrează mecanismul existent de backup/rollback.

## Ce aduce versiunea 1.3.3

- detecție robustă de versiune pentru serviciile cunoscute, inclusiv Postfix și Dovecot;
- fallback la versiunea pachetului;
- auto-update 1.3.0+ păstrat neschimbat.

## Ce aduce versiunea 1.3.1

- serviciile colectate pot raporta acum numele software, versiunea produsului și versiunea pachetului atunci când acestea pot fi determinate sigur;
- Linux detectează explicit versiuni pentru Postfix, Dovecot, Nginx, Apache, Redis, MariaDB/MySQL, PostgreSQL, HAProxy, Prometheus, Node Exporter, Filebeat, Auditbeat, SSSD, rsyslog, chrony, Docker, containerd, RabbitMQ, SOGo și PHP-FPM;
- Windows încearcă să citească ProductName/ProductVersion/FileVersion din executabilul serviciilor active;
- schema rămâne backward-compatible: câmpurile de versiune sunt opționale.


Agent Linux universal pentru colectarea inventarului local necesar fișei VM.
Versiunea 1.3.0 adaugă auto-update controlat de `vm-doc-server`, păstrând
colectarea inventarului o dată la 24 de ore și heartbeat-ul la 5 minute.

## Ce aduce 1.3.0

- auto-update controlat de serverul central, fără acces direct la GitHub;
- canale `stable` și `testing`;
- verificare SHA-256 și dimensiune înainte de instalare;
- verificarea versiunii executabilului descărcat înainte de înlocuire;
- helper separat `vm-doc-updater`, cu backup și rollback automat dacă noul agent nu trece `/health`;
- verificare periodică implicită la `6h`, cu instalare automată activată;
- API local nou: `GET /v1/update` și `POST /v1/update/check`;
- download-urile de update sunt acceptate numai de la aceeași origine ca `central.url`;
- `refresh_interval` rămâne `24h`, heartbeat `5m`;
- schema inventarului rămâne `2.0`.

## Funcții principale

- identitate persistentă `agent.id` și corelare prin UUID VMware/DMI;
- inventar JSON local și API HTTP protejat cu token Bearer;
- autoînregistrare outbound la serverul central;
- heartbeat periodic pentru starea online/offline;
- push automat al inventarului după fiecare colectare reușită;
- auto-update cu helper separat, validare SHA-256 și rollback;
- retry automat dacă serverul central nu este disponibil;
- compatibilitate cu systemd și SysV Init;
- binare statice `linux/amd64` (`GOAMD64=v1`) și `linux/386` (`GO386=softfloat`); installer multiarch cu detecție automată.

## Instalare nouă

```bash
# amd64 / x86_64
tar -xzf vm-doc-agent-1.6.11-linux-amd64.tar.gz
cd vm-doc-agent-1.6.11-linux-amd64
sudo ./install.sh

# i386/i486/i586/i686
tar -xzf vm-doc-agent-1.6.11-linux-386.tar.gz
cd vm-doc-agent-1.6.11-linux-386
sudo ./install.sh

# alternativ: un singur pachet care detectează arhitectura
tar -xzf vm-doc-agent-1.6.11-linux-multiarch.tar.gz
cd vm-doc-agent-1.6.11-linux-multiarch
sudo ./install.sh
```

Pachetul intern poate conține fișierul `central-registration-token`, iar
installerul îl copiază automat în:

```text
/etc/vm-doc-agent/central-registration-token
```

cu permisiuni `0600`.

Dacă pachetul nu conține tokenul, acesta poate fi furnizat la instalare:

```bash
sudo VM_DOC_CENTRAL_REGISTRATION_TOKEN='TOKEN' ./install.sh
```

## Configurare centrală implicită

```json
"central": {
  "enabled": true,
  "url": "http://172.20.1.20:9080",
  "registration_token_file": "/etc/vm-doc-agent/central-registration-token",
  "heartbeat_interval": "5m",
  "retry_interval": "1m",
  "request_timeout": "60s",
  "advertise_url": "",
  "ca_file": "",
  "tls_server_name": "",
  "insecure_skip_verify": false,
  "allow_http": true
}
```

`advertise_url` poate rămâne gol. Agentul folosește IP-ul interfeței cu ruta
implicită și portul din `listen`.

## Update manual

```bash
tar -xzf vm-doc-agent-1.6.11-linux-multiarch.tar.gz
cd vm-doc-agent-1.6.11-linux-multiarch
sudo ./update.sh
```

Updaterul păstrează configurația existentă, tokenul API local, `agent-id` și
inventarele existente. Pentru un agent 1.1.0 deja instalat, dacă `central` era
dezactivat, configurația existentă trebuie activată explicit; `update.sh` nu
suprascrie `config.json`.


## Auto-update

Configurația implicită este:

```json
"updates": {
  "enabled": true,
  "channel": "stable",
  "check_interval": "6h",
  "auto_install": true,
  "endpoint": "/api/v1/agent-updates/latest",
  "download_dir": "",
  "health_timeout": "45s",
  "max_download_bytes": 67108864
}
```

Un agent mai vechi de 1.3.0 trebuie actualizat manual **o singură dată** la 1.3.0.
După aceea, versiunile publicate de server pe canalul agentului pot fi instalate automat.

Verificare manuală:

```bash
TOKEN=$(sudo cat /etc/vm-doc-agent/token)
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/update
curl -X POST -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/update/check
```

## Verificare

```bash
/usr/local/sbin/vm-doc-agent -version
/usr/local/sbin/vm-doc-agent -config /etc/vm-doc-agent/config.json -check-config
sudo systemctl restart vm-doc-agent
sudo journalctl -u vm-doc-agent -n 100 --no-pager
```

În log trebuie să apară evenimentele:

```text
event=central_registered
event=central_inventory_pushed
```

## API local

```bash
curl http://127.0.0.1:9078/health
TOKEN=$(sudo cat /etc/vm-doc-agent/token)
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/status
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/inventory
```

## Build

```bash
./scripts/build.sh
CENTRAL_REGISTRATION_TOKEN='TOKEN' ./scripts/package.sh
./scripts/package-source.sh
```

**Important:** un pachet binar creat cu `CENTRAL_REGISTRATION_TOKEN` conține
secretul comun de bootstrap. Nu trebuie publicat într-un repository public.

Documentația detaliată se află în `docs/`.
