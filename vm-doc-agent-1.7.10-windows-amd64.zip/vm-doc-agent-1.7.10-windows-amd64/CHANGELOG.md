# Changelog

## 1.7.10

- Windows `listening_ports` nu mai folosește PowerShell/NetTCPIP; colectarea se face nativ prin `netstat -ano`;
- elimină bucla `Get-Process` per socket care putea depăși timeout-ul pe servere cu multe porturi;
- PID-urile sunt îmbogățite best-effort cu numele proceselor printr-un singur `tasklist`; indisponibilitatea `tasklist` nu invalidează porturile colectate;
- păstrează TCP `LISTENING`, endpoint-urile UDP, IPv4/IPv6, PID-ul și limitarea `max_ports`;
- schema inventarului rămâne `2.9`; Linux și restul colectorilor Windows nu se schimbă.

## 1.7.9

- Windows startup resilience: serverul HTTP/`/health` pornește înaintea inventarului inițial, astfel încât un CIM/WMI lent nu mai face agentul să pară offline;
- o eroare la inventarul inițial nu mai închide procesul: agentul rămâne `degraded` și reîncearcă automat la 30s;
- la restart este încărcat `inventory.json` valid existent, permițând reluarea heartbeat-ului central înainte de finalizarea unei colectări noi;
- înregistrarea centrală este amânată până există o identitate validă, evitând înregistrări goale la instalări noi;
- Windows identity (`Get-CimInstance`) folosește timeout de 45s și două încercări, iar aceeași interogare de bază nu mai este repetată de collectorul `system`;
- `/health` expune și `runtime_status` + `collection_in_progress`; schema inventarului rămâne `2.9`.

## 1.7.8

- Windows AV/EDR-friendly update: payload-urile agent/updater sunt descărcate ca `.payload`, nu ca `.new.exe`; SHA-256 rămâne obligatoriu, iar payload-ul Windows este validat ca PE înainte de instalare.
- Windows updater/installer: elimină secvența `*.new.exe -> rename -> *.exe`; binarele sunt copiate direct în destinația finală, cu backup, retry limitat și rollback.
- Windows software inventory: aplicațiile Desktop din Registry sunt colectate nativ în Go (HKLM x64/x86 + hive-uri HKEY_USERS încărcate), fără PowerShell; AppX/MSIX și Windows Features rămân surse PowerShell izolate.
- Windows PE: agentul și updaterul includ VERSIONINFO și application manifest generate offline în build, cu ProductName/FileDescription/FileVersion/ProductVersion și `asInvoker`.
- Enterprise signing: include script pentru semnare Authenticode cu `signtool`; release-ul poate fi semnat cu certificatul intern al organizației fără schimbări de cod.
- Păstrează schema inventarului 2.9 și compatibilitatea cu vm-doc-server 0.19.16+.

## 1.7.7

- Windows auto-update: restart robust al task-ului `vm-doc-agent`; updaterul execută explicit `/End`, așteaptă eliberarea instanței vechi și apoi `/Run`.
- Windows auto-update: aceeași secvență sigură este folosită la rollback.
- Windows auto-update: log detaliat pentru stop/start Task Scheduler, astfel încât un update eșuat să poată fi diagnosticat din `vm-doc-agent.log`.
- Include toate corecțiile 1.7.6 pentru collectorul `software`; schema rămâne 2.9.

## 1.7.6

- Windows software inventory: timeout minim 60s pentru collector.
- Registry, AppX/MSIX și Windows Features sunt colectate independent; timeout-ul unei surse produce warning/partial fără pierderea celorlalte date.
- Include fixul Task Scheduler pentru SYSTEM fără `LogonType=ServiceAccount`.
- Inventory schema rămâne 2.9.

## 1.7.4

- adaugă installer nativ Windows direct în `vm-doc-agent.exe`; comenzile `install`, `repair`, `status` și `uninstall` nu pornesc PowerShell și nu depind de `ExecutionPolicy`;
- mută binarele instalate în `C:\\Program Files\\VM-Doc\\Agent`, păstrând configurația, tokenurile, inventarul și logurile în `C:\\ProgramData\\VM-Doc\\Agent`;
- installerul nativ migrează instalațiile 1.7.0-1.7.3 bazate pe Scheduled Task, păstrează config/tokenul existent și recreează taskul `vm-doc-agent` sub `SYSTEM`, la startup, cu timp de execuție nelimitat și restart la eroare;
- configurează firewall-ul prin `netsh`, protejează state/config/token prin `icacls` și poate restricționa TCP/9078 cu `--firewall-remote`;
- adaugă suport pentru token din fișier (`--registration-token-file`), util pentru deployment securizat fără secret în command line;
- adaugă definiție MSI WiX x64 și scripturi de build. MSI folosește același installer nativ ca custom action elevat și nu necesită PowerShell pe mașina țintă;
- scripturile PowerShell rămân doar wrappers de compatibilitate peste installerul nativ; schema inventarului rămâne `2.9` și vm-doc-server rămâne 0.19.16.

## 1.7.3

- repară collectorul Windows `software` pe Windows PowerShell 5.1, unde `@($items)` peste `System.Collections.Generic.List[object]` putea eșua cu `Argument types do not match`;
- convertește explicit listele la `object[]` / `string[]` prin `ToArray()` înainte de `ConvertTo-Json`;
- suprimă valorile returnate de `List.Add()` pentru ca indecșii elementelor să nu ajungă accidental în stdout și să corupă JSON-ul collectorului;
- schema inventarului rămâne `2.9`; nu necesită upgrade de server peste vm-doc-server 0.19.16.

## 1.7.2

- adaugă collectorul Windows `software` pentru aplicații instalate din Registry x64/x86, hives user încărcate, AppX/MSIX și Windows Features/Roles;
- nu folosește `Win32_Product`, evitând verificările/reparările MSI nedorite;
- inventarul software păstrează nume, versiune, publisher, arhitectură, scope, sursă, data/calea instalării și marcajul de componentă de sistem;
- schema inventarului devine `2.9`; pe Linux collectorul software este raportat `unsupported`, fără impact asupra colectorilor existenți.

## 1.7.1

- repară `install.ps1`: `-CentralUrl` este aplicat înainte de migrarea/validarea unui config existent, astfel încât reinstalarea peste un config parțial nu mai eșuează cu `central.url must be an absolute URL`;
- detectează instanțele Microsoft SQL Server din Registry și Windows Services, inclusiv instanța implicită și instanțe numite;
- interoghează SQL Server local fără parolă prin ADO.NET + Windows Integrated Authentication (`SSPI`) sub identitatea agentului (`SYSTEM` în instalarea standard);
- colectează `ProductVersion`, `Edition`, numele instanței și `sys.databases`;
- marchează `master`, `model`, `msdb` și `tempdb` ca baze de sistem, astfel încât vm-doc-server 0.19.15+ să le ascundă din UI și documente;
- dacă loginul Windows lipsește sau nu are `VIEW ANY DATABASE`, raportează motiv secret-safe (`authentication_required` / `permission_denied`) și Rezumatul serverului semnalează inventarul DB incomplet;
- nu colectează parole, connection strings, SQL arbitrar sau date din tabele; schema inventarului rămâne `2.8`.

## 1.7.0

- adaugă suport Windows x64 pentru Windows Server 2016/2019/2022/2025 și Windows 10/11;
- colectează identitate/SMBIOS, OS, uptime/timezone, volume, rețea, hosts, proxy, Windows Services, porturi, Windows Firewall, conturi locale, Scheduled Tasks, W32Time, integrări, Docker metadata, motoare DB și IIS;
- clasifică Windows Services în `system`, `application` sau `unknown`;
- rulează persistent ca Scheduled Task `vm-doc-agent` sub `SYSTEM`, la startup, fără limită de execuție și cu restart automat;
- auto-update folosește repository-ul existent cu `os=windows`, `arch=amd64`;
- schema inventarului devine `2.8` atât pe Linux cât și pe Windows;
- Linux păstrează funcționalitatea 1.6.11 și buildurile amd64/386.

## 1.6.11

- recunoaște și masterul PostgreSQL vechi numit `postmaster`;
- identifică socketurile Unix PostgreSQL deținute efectiv de proces prin `/proc/<pid>/fd` + `/proc/net/unix`;
- preferă portul și socketul exact al instanței, util pe hosturi PostgreSQL 8/9 multi-instancă;
- încearcă toate socketurile locale candidate înainte de a raporta o eroare de autentificare/permisiune, fără fallback TCP sau user privilegiat;
- marchează explicit `postgres`, `template0` și `template1` ca baze PostgreSQL de sistem;
- schema inventarului rămâne `2.7`.

## 1.6.10

- adaugă fallback `su -s /bin/sh -c` când `runuser` lipsește, pentru SUSE/SLES 11 și alte distribuții vechi, atât la PostgreSQL cât și la MySQL/MariaDB;
- tratează separat instanțele PostgreSQL multiple folosind executabilul, data directory, portul și socket-urile detectate pentru fiecare proces;
- pentru PostgreSQL încearcă baza tehnică `postgres`, apoi `template1`, astfel încât instalațiile vechi/custom fără baza `postgres` să poată fi inventariate;
- încearcă mai întâi clientul `psql` din același director cu binarul `postgres`, util când coexistă versiuni PostgreSQL diferite pe același host;
- completează collectorul cron cu fallback `crontab -u postgres -l` dacă spool-ul userului postgres nu este vizibil direct;
- inventariază metadata joburilor PostgreSQL `pgAgent` și `pg_cron` fără a colecta SQL-ul/comanda/scriptul jobului;
- schema inventarului devine `2.7`; buildurile amd64/386/multiarch rămân disponibile.

## 1.6.9

- extinde discovery-ul PostgreSQL fără parolă folosind userul OS dedicat `vm-doc-inventory` și autentificare locală `peer`;
- rulează `psql` prin `runuser -u vm-doc-inventory` și folosește explicit rolul DB `vm-doc-inventory`;
- adaugă `psql -w`, astfel încât discovery-ul să nu poată solicita interactiv o parolă;
- dacă userul dedicat există dar peer/CONNECT eșuează, nu face fallback la `postgres`;
- dacă userul dedicat nu există, păstrează fallback-ul legacy prin userul OS `postgres`;
- schema inventarului rămâne 2.6 și serverul 0.19.13 nu necesită modificări.

## 1.6.8

- adaugă build static `linux/386` pe lângă `linux/amd64`; buildul 386 folosește `GO386=softfloat` pentru compatibilitate mai bună cu x86 vechi;
- installerul și update-ul detectează `x86_64/amd64` respectiv `i386/i486/i586/i686` și selectează binarul corect din pachetul multiarch;
- pachetele per-arhitectură includ `ARCHITECTURE` și refuză instalarea pe arhitectura greșită înainte să suprascrie binarul existent;
- `install.sh` și `update.sh` execută un preflight `-version` înainte de înlocuire, prevenind erori de tip `ELF: not found`;
- păstrează compatibilitatea SysV pentru Debian 7 și distribuțiile vechi; schema inventarului rămâne `2.6`.

## 1.6.7

- clasifică serviciile în `system`, `application` sau `unknown`, fără a elimina servicii din inventarul brut;
- adaugă `classification` și `classification_reason` pe fiecare element din `services`;
- folosește o combinație de produse cunoscute, servicii/pachete OS și unități systemd custom pentru clasificare conservatoare;
- serviciile neclasificate rămân `unknown`, astfel încât serverul să nu ascundă accidental software relevant;
- schema inventarului devine `2.6`.

## 1.6.6

- pentru MySQL/MariaDB preferă clientul `mysql`, cu fallback la `mariadb`, pentru compatibilitate cu instalările MariaDB 10 mai vechi;
- dacă există userul Linux `vm-doc-inventory`, enumerarea bazelor rulează prin `runuser -u vm-doc-inventory` și autentificare locală prin socket, fără parolă stocată;
- trimite explicit userul DB `vm-doc-inventory` și, când este detectată, calea reală a socket-ului instanței;
- dacă userul dedicat există dar autentificarea eșuează, nu reîncearcă drept root; dacă userul nu există, păstrează fallback-ul legacy pentru compatibilitate.

## 1.6.5

- adaugă `catalog_discovery_reason` pentru instanțele DB atunci când catalogul nu poate fi enumerat fără credențiale;
- clasifică motivele în coduri secret-safe: autentificare, permisiuni, socket/server indisponibil, client lipsă, timeout, utilizator OS lipsă sau query eșuat;
- nu trimite stderr brut și continuă să nu citească/stocheze parole sau connection strings.

## 1.6.4

- extinde collectorul Web pentru Apache HTTP Server astfel încât să pornească din configurația principală și să urmărească recursiv directivele `Include` și `IncludeOptional`;
- detectează configurația Apache și din argumentele procesului `-d` / `-f`, respectiv din `httpd/apache2 -V` (`HTTPD_ROOT` și `SERVER_CONFIG_FILE`);
- rezolvă include-urile relative față de `ServerRoot`, inclusiv glob-uri și directoare, cu deduplicare și protecție la bucle;
- inventariază astfel automat VirtualHost-uri din layout-uri precum `/etc/httpd/vhosts.d`, dar și din directoare custom definite de configurația Apache;
- nu modifică schema inventarului și nu necesită upgrade de server peste vm-doc-server 0.19.6.

## 1.6.3

- adaugă colectorul `hosts` pentru `/etc/hosts`;
- raportează structurat `hosts.entries[].ip` și `hosts.entries[].names`;
- ignoră loopback, comentarii, linii invalide și duplicate;
- schema inventarului devine `2.5`;
- colectorul este activ implicit și este adăugat automat în config la upgrade.


## 1.6.2

- corectează identitatea FQDN a VM-ului atunci când `hostname -f` urmărește un CNAME de serviciu și întoarce alt nume canonic decât hostname-ul mașinii;
- construiește FQDN-ul VM din hostname-ul local și domeniul de căutare DNS care rezolvă numele, păstrând ordinea configurată în resolver;
- păstrează separat rezultatul canonic DNS în `host.canonical_dns_name`, iar `host.fqdn_source` indică metoda folosită;
- exemplu: `hostname=kestra`, `kestra.xxx.ro CNAME nginx.xxx.ro` devine `fqdn=kestra.xxx.ro`, `canonical_dns_name=nginx.xxx.ro`;
- schema inventarului devine `2.4`; nu sunt necesare chei noi în `config.json`.

## 1.6.1

- extinde detecția Nginx pentru instalări custom, inclusiv sub `/opt`, folosind executabilul procesului, opțiunile `-p` / `-c` și căile compilate raportate de `nginx -V`;
- urmărește recursiv directivele `include` din configurația Nginx, inclusiv glob-uri relative la prefix, astfel încât virtual host-urile din layout-uri non-standard să fie inventariate;
- păstrează fixul PostgreSQL din 1.6.0: un proces `postgres` activ nu este degradat la `inactive` de unitatea generică `postgresql.service`.

## 1.6.0

- adaugă collectorul `web` pentru Nginx, Apache HTTP Server și HAProxy;
- colectează metadate despre site-uri, virtual hosts și frontends: nume publice, bind-uri, porturi, TLS, document root, backend-uri și ținte proxy;
- nu colectează conținut brut de configurație, parole, chei private, valori de headere sau alte secrete;
- adaugă limitele `max_web_servers` și `max_web_sites`, completate automat în `config.json` prin migrarea aditivă;
- corectează detecția stării PostgreSQL: un proces activ rămâne `running`, iar unitățile active de cluster sunt preferate în fața unității generice `postgresql.service` inactive.

## 1.5.0

- adaugă collectorul `databases` pentru PostgreSQL, MySQL, MariaDB, MongoDB, Oracle, Microsoft SQL Server, IBM Db2, Redis, Firebird și CockroachDB;
- colectează engine, versiune, instanțe, procese, servicii, directoare/config cunoscute și endpoint-uri fără parole sau connection strings;
- pentru PostgreSQL/MySQL/MariaDB/MongoDB încearcă best-effort enumerarea numelor bazelor doar prin acces local fără credențiale; dacă autentificarea nu permite, păstrează metadata instanței;
- `config.json` primește automat `collectors.databases` și limitele noi prin migrarea aditivă introdusă în 1.4.1.

## 1.4.1

- adaugă migrare aditivă a `config.json`: cheile noi sunt completate automat, fără suprascrierea valorilor existente;
- auto-updaterul rulează migrarea cu binarul nou înainte de pornirea serviciului;
- păstrează `/etc/vm-doc-agent/config.json.previous` înainte de update;
- rollback-ul de update restaurează acum atât binarul anterior, cât și configurația anterioară;
- `install.sh` și `update.sh` folosesc aceeași migrare de configurație;
- noua comandă `-migrate-config` poate fi folosită și manual pentru verificare/remediere;
- rezolvă cazul 1.3.x → 1.4.x în care `docker` și noile limite Docker nu apăreau fizic în fișierul existent.

## 1.4.0

- colector Docker nou pentru engine, containere, Compose projects, images, networks și volumes;
- colectează indicatori utili de securitate fără a prelua secrete: privileged, read-only rootfs, network mode, docker.sock mount, capabilities și resource limits;
- variabilele de mediu sunt inventariate numai prin nume, fără valori; valorile label-urilor sensibile sunt mascate;
- limite separate pentru obiectele Docker în inventar;
- păstrează selecția de IP de management introdusă în 1.3.7 și suportă `central.exclude_advertise_ips` cu IP-uri sau CIDR-uri.


## 1.3.6

- Adaugă log persistent propriu în `/var/log/vm-doc-agent.log` pentru procesul agentului.
- Păstrează în paralel logarea către stderr, deci pe systemd mesajele rămân disponibile și prin `journalctl`.
- Evită dublarea mesajelor pe SysV atunci când stderr este deja redirecționat către același fișier.
- Updaterul scrie în același log evenimentele `update_started`, `update_completed` și `update_failed`, util pentru depanarea auto-update-ului pe sisteme vechi.
- Păstrează compatibilitatea cu configurația logrotate existentă pentru `/var/log/vm-doc-agent.log`.

## 1.3.5

- Release de test pentru validarea auto-update-ului prin vm-doc-server.
- Fără modificări funcționale față de 1.3.4; doar incrementarea versiunii de build/release.

## 1.3.4

- repară auto-update-ul pe CentOS 7 / systemd 219 și alte versiuni systemd vechi;
- `systemd-run` folosește acum detectarea capabilităților din `--help`, fără a presupune că `--no-block` sau `--collect` există;
- elimină `Type=exec` din unitatea tranzitorie de update pentru compatibilitate cu systemd vechi;
- păstrează izolarea helperului de update într-o unitate systemd separată, astfel încât acesta să supraviețuiască opririi agentului;
- corectează versiunea implicită din `scripts/package-source.sh`.

## 1.3.3

- repară popularea versiunilor în `services[]`;
- adaugă detecție explicită pentru `vm-doc-agent.service`;
- adaugă fallback generic la pachetul care deține unitatea systemd / scriptul SysV;
- completează `package_name`, `package_version`, `version` și `version_source=package` pentru serviciile unde versiunea produsului nu poate fi detectată direct;
- interogările Debian sunt făcute în batch pentru a menține colectarea rapidă;
- mecanismul de auto-update 1.3.x rămâne neschimbat.

## 1.3.2

- detecție mai robustă a versiunilor pentru serviciile software principale;
- rezolvare explicită a executabilelor și din directoarele sbin;
- detecția versiunilor rulează concurent pentru a evita timeout-ul colectorului de servicii;
- păstrează integral mecanismul de auto-update din 1.3.0+.

## 1.3.1

- metadate software/version pentru serviciile colectate;
- detecție Postfix/Dovecot și alte produse uzuale pe Linux;
- ProductVersion/FileVersion pentru servicii active pe Windows;
- compatibilitate păstrată cu schema de inventar existentă.


## 1.3.0

### Adăugat

- auto-update centralizat prin `vm-doc-server`;
- canale `stable` / `testing`;
- verificare periodică implicită la `6h`;
- validare SHA-256, dimensiune și versiune pentru executabilele descărcate;
- helper separat `vm-doc-updater`;
- backup al binarului anterior și rollback automat dacă noua versiune nu trece health check-ul;
- endpoint-uri locale `GET /v1/update` și `POST /v1/update/check`;
- protecție same-origin pentru download-urile de update.

### Păstrat

- `refresh_interval=24h`;
- heartbeat central `5m`;
- schema inventarului `2.0`;
- central implicit `http://172.20.1.20:9080`, cu `allow_http=true`.

## 1.1.2

### Modificat

- `refresh_interval` implicit pentru instalările noi este `24h` în loc de `15m`;
- heartbeat-ul central rămâne la `5m`;
- refresh-ul manual continuă să declanșeze imediat colectarea și push-ul inventarului;
- configurația centrală implicită rămâne activă către `http://172.20.1.20:9080`, cu `allow_http=true`.

### Compatibilitate

- schema inventarului rămâne `2.0`;
- protocolul central rămâne versiunea `1`;
- `update.sh` păstrează configurația existentă, deci un agent deja instalat cu `15m` nu este schimbat automat la `24h`.

## 1.1.1

### Modificat

- autoînregistrarea este activată implicit pentru instalările noi;
- endpoint central implicit: `http://172.20.1.20:9080`;
- `central.allow_http=true` pentru profilul intern curent;
- installerul acceptă un token comun inclus în pachet sau furnizat prin `VM_DOC_CENTRAL_REGISTRATION_TOKEN`;
- pachetul intern poate instala automat `/etc/vm-doc-agent/central-registration-token` cu permisiuni `0600`.

### Compatibilitate

- schema inventarului rămâne `2.0`;
- protocolul central rămâne versiunea `1`;
- configurațiile existente sunt păstrate la update.

## 1.1.0

### Adăugat

- autoînregistrare la `vm-doc-server 0.2.2`;
- heartbeat periodic;
- push automat al inventarului după colectare;
- retry automat la indisponibilitatea serverului central;
- configurare TLS/CA și `advertise_url`;
- token de înregistrare separat de tokenul API local.

### Compatibilitate

- configurațiile 1.0.0 fără secțiunea `central` rămân valide;
- API-ul local și schema inventarului `2.0` nu se schimbă.


## 1.0.0

Prima versiune stabilă a agentului.

### Adăugat

- status individual pentru fiecare colector: `success`, `partial`, `timeout`, `error`, `disabled`;
- endpoint `GET /v1/status`;
- comenzi `-check-config`, `-collect-once`, `-print-inventory`, `-diagnostics`;
- activare/dezactivare individuală a colectoarelor;
- timeout global pentru colectoare și timeout separat pentru testarea output-urilor Beats;
- DNS, rute, gateway-uri, proxy, timezone, boot time și uptime;
- păstrarea atomică a `inventory.json.previous`;
- limite configurabile și metadata de truncare;
- loguri structurate și logrotate pentru SysV;
- documentație completă în `docs/`.

### Modificat

- schema JSON a trecut la `2.0`;
- installerul și updaterul validează configurația înainte de pornire;
- updaterul actualizează și fișierele de serviciu/logrotate;
- API-ul adaugă `Cache-Control: no-store` și jurnalizare cu status HTTP.

### Compatibilitate

Configurațiile 0.5.x fără câmpurile noi sunt acceptate și primesc valorile implicite din 1.0.0.
