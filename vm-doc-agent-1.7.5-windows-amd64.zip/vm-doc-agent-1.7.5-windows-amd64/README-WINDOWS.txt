vm-doc-agent Windows 1.7.5
==========================
Supported: Windows Server 2016/2019/2022/2025 and Windows 10/11 x64.
Administrator rights are required for install/repair/uninstall.
PowerShell is NOT required by the native installer and ExecutionPolicy is irrelevant.

NATIVE INSTALL - RECOMMENDED
----------------------------
Open an elevated Command Prompt or PowerShell only as a shell, then run the EXE directly:

  vm-doc-agent.exe install --central-url "http://vm-doc-server:9080"

If the registration token is not already present, an interactive install asks for it
with console echo disabled. For unattended deployment, prefer a protected token file:

  vm-doc-agent.exe install ^
    --central-url "http://vm-doc-server:9080" ^
    --registration-token-file "C:\Secure\vm-doc-registration-token.txt" ^
    --firewall-remote "172.20.0.0/16" ^
    --quiet

Installed binaries:
  C:\Program Files\VM-Doc\Agent\vm-doc-agent.exe
  C:\Program Files\VM-Doc\Agent\vm-doc-updater.exe

Persistent state/configuration:
  C:\ProgramData\VM-Doc\Agent\config.json
  C:\ProgramData\VM-Doc\Agent\central-registration-token
  C:\ProgramData\VM-Doc\Agent\inventory.json
  C:\ProgramData\VM-Doc\Agent\vm-doc-agent.log

The agent runs as Scheduled Task "vm-doc-agent" under SYSTEM at startup, with no
execution time limit and automatic restart on failure. Existing 1.7.0-1.7.3 config
and registration token are preserved during migration to the Program Files layout.

Useful native commands:
  vm-doc-agent.exe status
  vm-doc-agent.exe repair
  vm-doc-agent.exe uninstall
  vm-doc-agent.exe uninstall --purge

Firewall:
  default: TCP/9078 inbound, Domain+Private profiles, limited to the agent program
  optional restriction: --firewall-remote "172.20.0.0/16"
  no managed rule:       --no-firewall-rule

PowerShell install.ps1/update.ps1/uninstall.ps1 remain in the ZIP only as compatibility
wrappers. They call the native EXE lifecycle and are not required.

MSI DEPLOYMENT
--------------
The source tree includes packaging/windows/msi/vm-doc-agent.wxs. The MSI installs the
x64 binaries under Program Files and then invokes the same native installer as an
elevated deferred custom action; it does not launch PowerShell on the target machine.

Fresh silent install example:
  msiexec /i vm-doc-agent-1.7.5-windows-amd64.msi /qn ^
    CENTRALURL="http://vm-doc-server:9080" ^
    REGISTRATIONTOKEN="<registration-token>" ^
    FIREWALLREMOTE="172.20.0.0/16"

Preferred unattended secret handling when a protected local token file is provisioned:
  msiexec /i vm-doc-agent-1.7.5-windows-amd64.msi /qn ^
    CENTRALURL="http://vm-doc-server:9080" ^
    REGISTRATIONTOKENFILE="C:\Secure\vm-doc-registration-token.txt"

Sign both EXE files and the MSI with the organization's Authenticode code-signing
certificate before enterprise deployment when AppLocker/WDAC/AllSigned policies require it.

Auto-update:
Publish vm-doc-agent.exe and vm-doc-updater.exe in vm-doc-server as os=windows, arch=amd64.

Microsoft SQL Server discovery (1.7.1+)
---------------------------------------
The agent uses Windows Integrated Authentication (SSPI) through built-in ADO.NET.
No sqlcmd installation and no SQL password are required. Standard installation runs
as NT AUTHORITY\SYSTEM. In every local SQL Server instance that should be inventoried:

  IF SUSER_ID(N'NT AUTHORITY\SYSTEM') IS NULL
      CREATE LOGIN [NT AUTHORITY\SYSTEM] FROM WINDOWS;
  GRANT VIEW ANY DATABASE TO [NT AUTHORITY\SYSTEM];

Do not grant sysadmin/db_owner. System databases master/model/msdb/tempdb are kept in
raw inventory with system=true and hidden by vm-doc-server 0.19.15+ UI/documents.
