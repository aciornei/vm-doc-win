@echo off
setlocal EnableExtensions
rem Sign VM-Doc Windows artifacts with an enterprise Authenticode certificate.
rem Required: SIGN_CERT_SHA1. Optional: SIGN_TIMESTAMP_URL, SIGN_STORE_MACHINE=1.

if "%SIGN_CERT_SHA1%"=="" (
  echo ERROR: set SIGN_CERT_SHA1 to the code-signing certificate thumbprint.
  exit /b 2
)
where signtool.exe >nul 2>&1 || (
  echo ERROR: signtool.exe was not found in PATH. Install/use the Windows SDK.
  exit /b 2
)

set ROOT=%~dp0\..\..
set AGENT=%ROOT%\dist\windows-amd64\vm-doc-agent.exe
set UPDATER=%ROOT%\dist\windows-amd64\vm-doc-updater.exe
set STORE=
if /I "%SIGN_STORE_MACHINE%"=="1" set STORE=/sm
set TS=
if not "%SIGN_TIMESTAMP_URL%"=="" set TS=/tr "%SIGN_TIMESTAMP_URL%" /td SHA256

for %%F in ("%AGENT%" "%UPDATER%") do (
  if not exist "%%~F" (
    echo ERROR: missing %%~F
    exit /b 2
  )
  echo Signing %%~F
  signtool.exe sign %STORE% /sha1 "%SIGN_CERT_SHA1%" /fd SHA256 %TS% "%%~F" || exit /b 1
  signtool.exe verify /pa /v "%%~F" || exit /b 1
)

if not "%~1"=="" (
  if not exist "%~1" (
    echo ERROR: MSI not found: %~1
    exit /b 2
  )
  echo Signing %~1
  signtool.exe sign %STORE% /sha1 "%SIGN_CERT_SHA1%" /fd SHA256 %TS% "%~1" || exit /b 1
  signtool.exe verify /pa /v "%~1" || exit /b 1
)

echo Authenticode signing completed.
endlocal
