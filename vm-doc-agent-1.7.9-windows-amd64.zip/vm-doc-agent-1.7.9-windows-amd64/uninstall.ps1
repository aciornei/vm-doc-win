[CmdletBinding()]
param([switch]$Purge)
$ErrorActionPreference='Stop'
$ScriptDir=Split-Path -Parent $MyInvocation.MyCommand.Path
$PackageAgent=Join-Path $ScriptDir 'vm-doc-agent.exe'
$InstalledAgent=Join-Path $env:ProgramFiles 'VM-Doc\Agent\vm-doc-agent.exe'
$Agent = if (Test-Path $InstalledAgent) { $InstalledAgent } else { $PackageAgent }
if (-not (Test-Path $Agent)) { throw "vm-doc-agent.exe not found" }
$argsList=@('uninstall')
if ($Purge) { $argsList += '--purge' }
& $Agent @argsList
if ($LASTEXITCODE -ne 0) { throw "vm-doc-agent native uninstall failed with exit code $LASTEXITCODE" }
