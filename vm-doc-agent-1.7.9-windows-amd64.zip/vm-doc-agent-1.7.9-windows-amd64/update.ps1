[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
$ScriptDir=Split-Path -Parent $MyInvocation.MyCommand.Path
$Agent=Join-Path $ScriptDir 'vm-doc-agent.exe'
if (-not (Test-Path $Agent)) { throw "Missing $Agent" }
& $Agent install
if ($LASTEXITCODE -ne 0) { throw "vm-doc-agent native update/install failed with exit code $LASTEXITCODE" }
