[CmdletBinding()]
param(
    [string]$CentralUrl = "",
    [string]$RegistrationToken = "",
    [string]$RegistrationTokenFile = "",
    [string]$FirewallRemote = "",
    [switch]$NoFirewallRule
)
$ErrorActionPreference = 'Stop'
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Agent = Join-Path $ScriptDir 'vm-doc-agent.exe'
if (-not (Test-Path $Agent)) { throw "Missing $Agent" }
$argsList = @('install')
if ($CentralUrl) { $argsList += @('--central-url', $CentralUrl) }
if ($RegistrationToken) { $argsList += @('--registration-token', $RegistrationToken) }
if ($RegistrationTokenFile) { $argsList += @('--registration-token-file', $RegistrationTokenFile) }
if ($FirewallRemote) { $argsList += @('--firewall-remote', $FirewallRemote) }
if ($NoFirewallRule) { $argsList += '--no-firewall-rule' }
& $Agent @argsList
if ($LASTEXITCODE -ne 0) { throw "vm-doc-agent native installer failed with exit code $LASTEXITCODE" }
