vm-doc-agent Windows
====================
Supported first release: Windows Server 2016/2019/2022/2025 and Windows 10/11 x64.
Requires Windows PowerShell 5.1 and Administrator rights for installation.

Install (elevated PowerShell):
  Set-ExecutionPolicy -Scope Process Bypass
  .\install.ps1 -CentralUrl "http://vm-doc-server:9080"

The installer asks for the central registration token if one is not already present.
The agent runs as Scheduled Task "vm-doc-agent" under SYSTEM at startup, with no execution time limit.

Useful checks:
  Get-ScheduledTask -TaskName vm-doc-agent
  Invoke-RestMethod http://127.0.0.1:9078/health
  Get-Content "$env:ProgramData\VM-Doc\Agent\vm-doc-agent.log" -Tail 100

Auto-update:
Publish vm-doc-agent.exe and vm-doc-updater.exe in vm-doc-server as os=windows, arch=amd64.
