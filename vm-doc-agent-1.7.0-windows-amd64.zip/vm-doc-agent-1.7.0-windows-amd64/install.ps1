[CmdletBinding()]
param(
    [string]$CentralUrl = "",
    [string]$RegistrationToken = "",
    [switch]$NoFirewallRule
)
$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSVersion.Major -lt 5) { throw 'Windows PowerShell 5.1 or newer is required.' }
$TaskName = 'vm-doc-agent'
$Base = Join-Path $env:ProgramData 'VM-Doc\Agent'
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$AgentSource = Join-Path $ScriptDir 'vm-doc-agent.exe'
$UpdaterSource = Join-Path $ScriptDir 'vm-doc-updater.exe'
$ConfigSource = Join-Path $ScriptDir 'config.json'
$Agent = Join-Path $Base 'vm-doc-agent.exe'
$Updater = Join-Path $Base 'vm-doc-updater.exe'
$Config = Join-Path $Base 'config.json'
$RegistrationTokenFile = Join-Path $Base 'central-registration-token'

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run PowerShell as Administrator.'
}
if (-not (Test-Path $AgentSource)) { throw "Missing $AgentSource" }
if (-not (Test-Path $UpdaterSource)) { throw "Missing $UpdaterSource" }
if (-not (Test-Path $ConfigSource)) { throw "Missing $ConfigSource" }

New-Item -ItemType Directory -Path $Base -Force | Out-Null
try { Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue } catch {}
Start-Sleep -Milliseconds 500
if (Test-Path $Agent) { Copy-Item $Agent ($Agent + '.previous') -Force }
Copy-Item $AgentSource $Agent -Force
Copy-Item $UpdaterSource $Updater -Force

if (-not (Test-Path $Config)) {
    Copy-Item $ConfigSource $Config -Force
} else {
    & $Agent -config $Config -migrate-config | Out-Host
}

if ($CentralUrl) {
    $json = Get-Content $Config -Raw | ConvertFrom-Json
    $json.central.url = $CentralUrl.TrimEnd('/')
    $jsonText = $json | ConvertTo-Json -Depth 20
    [IO.File]::WriteAllText($Config, $jsonText, (New-Object Text.UTF8Encoding($false)))
}
if (-not $RegistrationToken -and -not (Test-Path $RegistrationTokenFile)) {
    $secureToken = Read-Host 'Central registration token' -AsSecureString
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureToken)
    try { $RegistrationToken = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}
if ($RegistrationToken) {
    [IO.File]::WriteAllText($RegistrationTokenFile, $RegistrationToken.Trim(), (New-Object Text.UTF8Encoding($false)))
}
if (-not (Test-Path $RegistrationTokenFile)) { throw "Missing registration token: $RegistrationTokenFile" }

# Protect state/config/token from ordinary local users. SYSTEM and Administrators retain Full Control.
& icacls.exe $Base /inheritance:r /grant:r 'SYSTEM:(OI)(CI)F' 'BUILTIN\Administrators:(OI)(CI)F' | Out-Null

& $Agent -config $Config -check-config | Out-Null
& $Agent -version

$action = New-ScheduledTaskAction -Execute $Agent -Argument ('-config "{0}"' -f $Config)
$trigger = New-ScheduledTaskTrigger -AtStartup
$settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -StartWhenAvailable -MultipleInstances IgnoreNew
$taskPrincipal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings -Principal $taskPrincipal -Force | Out-Null

if (-not $NoFirewallRule) {
    if (Get-Command New-NetFirewallRule -ErrorAction SilentlyContinue) {
        Get-NetFirewallRule -DisplayName 'VM-Doc Agent 9078' -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
        New-NetFirewallRule -DisplayName 'VM-Doc Agent 9078' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 9078 -Profile Domain,Private | Out-Null
    }
}
Start-ScheduledTask -TaskName $TaskName
Start-Sleep -Seconds 3
try {
    $health = Invoke-RestMethod -Uri 'http://127.0.0.1:9078/health' -TimeoutSec 5
    Write-Host ("Installed vm-doc-agent. Health={0}" -f $health.status)
} catch {
    Write-Warning 'Task was installed and started, but health endpoint is not reachable yet. Check vm-doc-agent.log and Task Scheduler.'
}
Write-Host "Path: $Base"
Write-Host "Task: $TaskName (SYSTEM, AtStartup, unlimited execution time)"
