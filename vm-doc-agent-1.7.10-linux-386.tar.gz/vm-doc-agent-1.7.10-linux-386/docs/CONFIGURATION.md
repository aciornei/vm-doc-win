# Configurație

Fișier implicit:

```text
/etc/vm-doc-agent/config.json
```

Configurație completă:

```json
{
  "listen": "0.0.0.0:9078",
  "output_file": "/var/lib/vm-doc-agent/inventory.json",
  "state_dir": "/var/lib/vm-doc-agent",
  "refresh_interval": "24h",
  "auth_token_file": "/etc/vm-doc-agent/token",
  "collector_timeout": "20s",
  "output_test_timeout": "12s",
  "collectors": {
    "system": true,
    "storage": true,
    "network": true,
    "proxy": true,
    "services": true,
    "listening_ports": true,
    "firewall": true,
    "accounts": true,
    "sssd": true,
    "integrations": true,
    "policies": true,
    "cron": true,
    "ntp": true
  },
  "limits": {
    "max_partitions": 1000,
    "max_routes": 5000,
    "max_services": 5000,
    "max_ports": 5000,
    "max_firewall_rules": 10000,
    "max_firewall_zones": 1000,
    "max_accounts": 10000,
    "max_cron_entries": 5000,
    "max_cron_scripts": 5000,
    "max_policy_files": 10000,
    "max_inventory_bytes": 20971520
  },
  "policy_paths": []
}
```

## Validare

```bash
/usr/local/sbin/vm-doc-agent \
  -config /etc/vm-doc-agent/config.json \
  -check-config
```

Câmpurile necunoscute produc eroare, pentru a evita greșelile de scriere.

## Dezactivarea unui colector

```json
"collectors": {
  "cron": false,
  "accounts": false
}
```

Un colector dezactivat apare în inventar cu status `disabled`.

## Politici organizaționale

```json
"policy_paths": [
  "/etc/company/policies/*",
  "/opt/company/policy-markers",
  "/etc/company/hardening.conf"
]
```

Agentul salvează metadata și SHA256, nu conținutul complet.

## Timeout-uri

- `collector_timeout`: timpul maxim acordat unui colector;
- `output_test_timeout`: timpul maxim pentru `filebeat test output` și `auditbeat test output`.

Dacă un colector depășește timeout-ul, restul colectării continuă.

## Conectarea la serverul central

```json
"central": {
  "enabled": true,
  "url": "http://172.20.1.20:9080",
  "registration_token_file": "/etc/vm-doc-agent/central-registration-token",
  "heartbeat_interval": "5m",
  "retry_interval": "1m",
  "request_timeout": "60s",
  "advertise_url": "",
  "ca_file": "/etc/vm-doc-agent/ca/central-ca.pem",
  "tls_server_name": "",
  "insecure_skip_verify": false,
  "allow_http": true
}
```

- `url`: adresa publicată de nodul central, fără calea API;
- `registration_token_file`: token comun, cu permisiuni `0600`;
- `heartbeat_interval`: cât de des este actualizată starea online;
- `retry_interval`: intervalul de retry după o eroare;
- `advertise_url`: URL-ul prin care serverul poate apela API-ul local; gol în mod normal;
- `ca_file`: CA PEM pentru PKI intern;
- `insecure_skip_verify`: doar pentru diagnostic temporar;
- `allow_http`: permite HTTP. În profilul intern 1.3.0 este activat pentru `172.20.1.20:9080`; traficul trebuie limitat la rețeaua de management.

## Cadența implicită în 1.3.0

În 1.3.0, valoarea implicită este `24h`: inventarul complet este recollectat o dată pe zi. Heartbeat-ul central (`5m`) este separat și continuă să indice starea online a agentului. Un refresh manual nu așteaptă intervalul de 24 de ore.

## Docker (1.4.0+)

Colectorul `docker` este activ implicit. El folosește Docker CLI local și colectează engine-ul, containerele, proiectele Compose, imaginile, rețelele și volumele. Nu colectează valorile variabilelor de mediu, secretele, logurile sau conținutul fișierelor montate.

```json
"collectors": {
  "docker": true
},
"limits": {
  "max_docker_containers": 2000,
  "max_docker_images": 5000,
  "max_docker_networks": 1000,
  "max_docker_volumes": 2000
}
```

Pentru asocierea automată pe server pot fi folosite labels opționale: `vm-doc.service`, `vm-doc.services`, `vm-doc.component` și `vm-doc.role`.

Pentru hosturi cu VIP-uri se pot exclude explicit IP-uri sau rețele de la alegerea adresei de management:

```json
"central": {
  "exclude_advertise_ips": ["172.20.1.20", "10.10.0.0/24"]
}
```

## Migrarea configurației la upgrade (1.4.1+)

La upgrade, agentul nu înlocuiește configurația locală cu `config.json` din pachet. În schimb, completează numai cheile care lipsesc din schema versiunii noi. Valorile locale pentru URL central, intervale, colectoare dezactivate, canale de update, IP-uri excluse etc. rămân neschimbate.

Exemplu pentru un agent 1.3.7 actualizat la 1.4.1: dacă `collectors.docker` și limitele Docker lipsesc, ele sunt adăugate cu valorile implicite, fără a modifica restul configurației.

Migrarea manuală:

```bash
/usr/local/sbin/vm-doc-agent \
  -config /etc/vm-doc-agent/config.json \
  -migrate-config
```

Înaintea auto-update-ului se păstrează și:

```text
/etc/vm-doc-agent/config.json.previous
```

Dacă migrarea configurației sau health-check-ul noii versiuni eșuează, updaterul restaurează automat atât binarul anterior, cât și configurația anterioară.

## Inventar baze de date (1.5.0+)

Collectorul este activ implicit:

```json
"collectors": {
  "databases": true
},
"limits": {
  "max_database_instances": 500,
  "max_database_catalogs": 2000
}
```

Sunt detectate PostgreSQL, MySQL, MariaDB, MongoDB, Oracle Database, Microsoft SQL Server, IBM Db2, Redis, Firebird și CockroachDB. Pentru PostgreSQL, MySQL/MariaDB și MongoDB, agentul încearcă local enumerarea numelor bazelor numai dacă autentificarea existentă permite acces fără furnizarea unor credențiale către agent. Dacă nu, instanța rămâne inventariată cu `catalog_discovery_status=metadata_only`. Agentul nu citește parole, connection strings, conținut de tabele sau variabile de mediu arbitrare.

### Microsoft SQL Server pe Windows (1.7.1+)

Pe Windows, instanțele SQL Server sunt identificate din Registry și Windows Services. Agentul standard rulează ca `SYSTEM` și folosește ADO.NET `System.Data.SqlClient` cu Windows Integrated Authentication (`SSPI`), fără user/parolă în config. Pentru enumerarea completă a bazelor, fiecare instanță SQL Server trebuie să permită loginul Windows folosit de agent și dreptul server-level `VIEW ANY DATABASE`. Configurația minimă recomandată pentru instalarea standard este:

```sql
IF SUSER_ID(N'NT AUTHORITY\SYSTEM') IS NULL
    CREATE LOGIN [NT AUTHORITY\SYSTEM] FROM WINDOWS;
GRANT VIEW ANY DATABASE TO [NT AUTHORITY\SYSTEM];
```

Nu acordați `sysadmin`, `db_owner` sau acces la datele aplicațiilor. Agentul execută doar interogări fixe pentru `SERVERPROPERTY`, `HAS_PERMS_BY_NAME` și `sys.databases`. Bazele `master`, `model`, `msdb` și `tempdb` sunt raportate cu `system=true`, astfel încât serverul să le păstreze în inventarul brut dar să nu le afișeze în UI/fișe. Dacă loginul lipsește, `catalog_discovery_reason=authentication_required`; dacă lipsește `VIEW ANY DATABASE`, discovery-ul este `partial` cu `permission_denied`.


## Inventar web (1.6.0+)

Collectorul este activ implicit:

```json
"collectors": {
  "web": true
},
"limits": {
  "max_web_servers": 100,
  "max_web_sites": 5000
}
```

Sunt detectate Nginx, Apache HTTP Server și HAProxy. Inventarul conține numai metadate utile documentării: produs/versiune/stare, fișiere de configurare cunoscute, site-uri sau frontends, nume publice, bind-uri și porturi, document root, backend-uri și ținte proxy. Agentul nu trimite conținutul brut al configurațiilor, credențiale, chei private sau valori de headere. La upgrade de la 1.5.0, cheile noi sunt adăugate automat fără suprascrierea valorilor existente.


## Hosts local (1.6.3)

Colectorul `hosts` citește `/etc/hosts` și publică mapări structurate `IP -> names`. Colectorul este activ implicit prin `collectors.hosts=true`. Adresele loopback și duplicatele nu sunt raportate.

### Apache Include/IncludeOptional (1.6.4+)

Collectorul Web urmărește recursiv configurația Apache pornind din fișierul principal și rezolvă `Include` / `IncludeOptional` față de `ServerRoot`. VirtualHost-urile pot fi păstrate în orice director referit de configurație; nu este necesară configurarea unei liste fixe de directoare în agent.
