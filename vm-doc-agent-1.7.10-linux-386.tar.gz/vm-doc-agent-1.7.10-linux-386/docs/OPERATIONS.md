# Operațiuni și diagnostic

## Versiune

```bash
vm-doc-agent -version
```

## Validarea configurației

```bash
vm-doc-agent -config /etc/vm-doc-agent/config.json -check-config
```

## Colectare unică și salvare

```bash
vm-doc-agent -config /etc/vm-doc-agent/config.json -collect-once
```

## Colectare unică și afișare pe stdout

```bash
vm-doc-agent -config /etc/vm-doc-agent/config.json -print-inventory
```

## Diagnostic sigur

```bash
vm-doc-agent -config /etc/vm-doc-agent/config.json -diagnostics
```

Raportul de diagnostic conține configurația fără token, metadata fișierelor, identificarea hostului, statusul colectoarelor și avertismentele.

## Inventar curent și anterior

```text
/var/lib/vm-doc-agent/inventory.json
/var/lib/vm-doc-agent/inventory.json.previous
```

Fișierul anterior este actualizat numai dacă inventarul curent este JSON valid.

## Loguri

Systemd:

```bash
journalctl -u vm-doc-agent --since today
```

SysV:

```bash
tail -f /var/log/vm-doc-agent.log
```

Evenimentele includ `collection_started`, `collection_completed`, `http_request`, `unauthorized_request` și erorile de scriere.

## Auto-update

Status:

```bash
TOKEN=$(cat /etc/vm-doc-agent/token)
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/update
```

Forțare verificare și instalare, dacă serverul publică o versiune mai nouă:

```bash
curl -X POST -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/update/check
```

Helperul de update este `/usr/local/sbin/vm-doc-updater`. Binarul anterior al agentului este păstrat ca `vm-doc-agent.previous`; dacă health check-ul noii versiuni eșuează, helperul revine automat la versiunea anterioară.


### Log propriu (1.3.6+)

Agentul și updaterul scriu direct în `/var/log/vm-doc-agent.log`. Pe systemd mesajele sunt păstrate și în journal. Pentru urmărire în timp real: `tail -f /var/log/vm-doc-agent.log`.


## MySQL/MariaDB inventory fără parolă (1.6.6+)

Pe serverele unde `vm-doc-agent` rulează ca root, recomandarea este să păstrați serviciul neschimbat și să creați separat userul Linux `vm-doc-inventory`. Pentru MariaDB cu pluginul `unix_socket`, creați userul DB cu același nume și acordați numai `SHOW DATABASES`. Agentul detectează userul și rulează discovery prin `runuser` sau, pe sisteme vechi fără acesta, prin `su -s /bin/sh -c`; clientul `mysql` fiind preferat înainte de `mariadb`. Dacă instanța raportează un socket explicit, agentul îl pasează clientului. Nu sunt necesare parole în `config.json`.

## PostgreSQL inventory fără parolă (1.6.9+)

Pe hosturile PostgreSQL, păstrați `vm-doc-agent` ca root și creați userul Linux `vm-doc-inventory`. Creați în PostgreSQL rolul `"vm-doc-inventory"` fără privilegii administrative și permiteți numai conectarea locală la baza tehnică `postgres` prin `peer`. Linia dedicată din `pg_hba.conf` trebuie plasată înaintea regulilor locale mai generale care cer `md5`/`scram-sha-256`. Agentul rulează `psql` sub `vm-doc-inventory` prin `runuser` sau `su` și cu `-w`, deci nu stochează, nu transmite și nu solicită parole. Dacă userul dedicat nu există, rămâne disponibil fallback-ul legacy prin userul OS `postgres`.

Exemplu PostgreSQL:

```sql
CREATE ROLE "vm-doc-inventory" LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION;
GRANT CONNECT ON DATABASE postgres TO "vm-doc-inventory";
```

Exemplu `pg_hba.conf`:

```text
local   postgres   vm-doc-inventory   peer
```

Test local:

```bash
runuser -u vm-doc-inventory -- psql -AtX -w -U vm-doc-inventory -d postgres -c "SELECT datname FROM pg_database WHERE datistemplate=false ORDER BY datname"
```



## PostgreSQL vechi / SUSE 11 / mai multe instanțe (1.6.10+)

Pe hosturile fără `runuser` (de exemplu SUSE/SLES 11), agentul folosește automat `su -s /bin/sh -c` pentru a rula clientul DB sub `vm-doc-inventory`. Aceeași regulă se aplică PostgreSQL și MySQL/MariaDB.

La mai multe instanțe PostgreSQL, agentul folosește portul/socket-ul detectat al fiecărei instanțe și preferă `psql` aflat lângă executabilul `postgres` al instanței. Pentru baza tehnică încearcă `postgres`, apoi `template1`. Pe PostgreSQL vechi, `pg_hba.conf` poate folosi metoda locală disponibilă versiunii (`ident`/sameuser pe versiunile vechi sau `peer` pe versiunile mai noi), păstrând aceeași identitate OS/DB `vm-doc-inventory`.

Collectorul cron citește spool-urile cunoscute și, dacă nu vede intrările userului `postgres`, execută read-only `crontab -u postgres -l`. Separat, collectorul `databases` încearcă să identifice joburi `pgAgent`/`pg_cron`; comenzile SQL/scripturile joburilor nu sunt colectate.


## PostgreSQL 8/9 multi-instance · 1.6.11

Pentru hosturi vechi pe care coexistă mai multe clustere PostgreSQL, 1.6.11 recunoaște atât procesul `postgres`, cât și `postmaster`. Agentul corelează socketurile Unix deținute efectiv de proces folosind `/proc/<pid>/fd` și `/proc/net/unix`, apoi preferă acel socket și portul lui înaintea configurațiilor implicite ale clientului `psql`. Acest lucru evită interogarea accidentală a clusterului implicit când, de exemplu, PostgreSQL 8 rulează pe 5434 iar PostgreSQL 9 pe 5432.

Bazele tehnice PostgreSQL `postgres`, `template0` și `template1` sunt marcate ca baze de sistem. Agentul le păstrează în inventarul brut, iar vm-doc-server 0.19.15+ le ascunde din UI și documentație.
