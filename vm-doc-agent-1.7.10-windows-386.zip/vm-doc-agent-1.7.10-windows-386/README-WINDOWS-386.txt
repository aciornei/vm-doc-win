VM-Doc Agent 1.7.10 - Windows 386 (x86)
========================================

This package contains the 32-bit Windows builds:
  vm-doc-agent.exe
  vm-doc-updater.exe

Publish for auto-update as:
  os=windows
  arch=386

The listening_ports collector in 1.7.10 uses native netstat -ano and one tasklist
lookup instead of PowerShell Get-NetTCPConnection/Get-NetUDPEndpoint.

IMPORTANT LEGACY WINDOWS NOTE
-----------------------------
This standard 1.7.10 x86 build was compiled with the current Go toolchain used for
the normal release. It is NOT the special legacy build for Windows XP / Server 2003.
Those systems require the separate legacy-compatible toolchain/build.
