[CmdletBinding()]
param([switch]$Purge)
$ErrorActionPreference='Stop'
$TaskName='vm-doc-agent'
$Base=Join-Path $env:ProgramData 'VM-Doc\Agent'
Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
if (Get-Command Get-NetFirewallRule -ErrorAction SilentlyContinue) {
    Get-NetFirewallRule -DisplayName 'VM-Doc Agent 9078' -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
}
if ($Purge) { Remove-Item $Base -Recurse -Force -ErrorAction SilentlyContinue }
else {
    Remove-Item (Join-Path $Base 'vm-doc-agent.exe') -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $Base 'vm-doc-updater.exe') -Force -ErrorAction SilentlyContinue
}
Write-Host 'vm-doc-agent task removed.'
