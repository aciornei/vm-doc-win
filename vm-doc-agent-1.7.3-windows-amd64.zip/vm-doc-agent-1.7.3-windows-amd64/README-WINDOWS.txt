vm-doc-agent Windows 1.7.3
==========================
Supported first release: Windows Server 2016/2019/2022/2025 and Windows 10/11 x64.
Requires Windows PowerShell 5.1 and Administrator rights for installation.

Install (elevated PowerShell):
  Set-ExecutionPolicy -Scope Process Bypass
  .\install.ps1 -CentralUrl "http://vm-doc-server:9080"

The installer asks for the central registration token if one is not already present.
The agent runs as Scheduled Task "vm-doc-agent" under SYSTEM at startup, with no execution time limit.

Useful checks:
  Get-ScheduledTask -TaskName vm-doc-agent
  Invoke-RestMethod http://127.0.0.1:9078/health
  Get-Content "$env:ProgramData\VM-Doc\Agent\vm-doc-agent.log" -Tail 100

Auto-update:
Publish vm-doc-agent.exe and vm-doc-updater.exe in vm-doc-server as os=windows, arch=amd64.


Microsoft SQL Server discovery (1.7.1+)
---------------------------------------
The agent uses Windows Integrated Authentication (SSPI) through built-in ADO.NET.
No sqlcmd installation and no SQL password are required. Standard installation runs
as NT AUTHORITY\SYSTEM. In every local SQL Server instance that should be inventoried:

  IF SUSER_ID(N'NT AUTHORITY\SYSTEM') IS NULL
      CREATE LOGIN [NT AUTHORITY\SYSTEM] FROM WINDOWS;
  GRANT VIEW ANY DATABASE TO [NT AUTHORITY\SYSTEM];

Do not grant sysadmin/db_owner. System databases master/model/msdb/tempdb are kept in
raw inventory with system=true and hidden by vm-doc-server 0.19.15+ UI/documents.
