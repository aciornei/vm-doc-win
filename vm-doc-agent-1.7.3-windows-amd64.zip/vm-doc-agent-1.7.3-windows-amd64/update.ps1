[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
$TaskName='vm-doc-agent'
$Base=Join-Path $env:ProgramData 'VM-Doc\Agent'
$ScriptDir=Split-Path -Parent $MyInvocation.MyCommand.Path
$AgentSource=Join-Path $ScriptDir 'vm-doc-agent.exe'
$UpdaterSource=Join-Path $ScriptDir 'vm-doc-updater.exe'
$Agent=Join-Path $Base 'vm-doc-agent.exe'
$Updater=Join-Path $Base 'vm-doc-updater.exe'
$Config=Join-Path $Base 'config.json'
if (-not (Test-Path $Agent)) { throw 'Agent is not installed; use install.ps1.' }
& $AgentSource -version
Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
Start-Sleep -Seconds 1
Copy-Item $Agent ($Agent + '.previous') -Force
Copy-Item $AgentSource $Agent -Force
Copy-Item $UpdaterSource $Updater -Force
& $Agent -config $Config -migrate-config | Out-Host
& $Agent -config $Config -check-config | Out-Null
Start-ScheduledTask -TaskName $TaskName
Start-Sleep -Seconds 3
& $Agent -version
Write-Host 'Manual update completed.'
