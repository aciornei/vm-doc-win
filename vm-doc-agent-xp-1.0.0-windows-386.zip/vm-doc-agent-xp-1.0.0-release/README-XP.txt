VM-Doc Agent XP 1.0.0
=====================

Scop
----
Ramura legacy pentru Windows XP SP3 / Windows Server 2003, destinata unui numar
mic de masini vechi care trebuie sa ramana vizibile in vm-doc-server.

IMPORTANT
---------
Acest agent este separat de vm-doc-agent 1.7.x. Nu trebuie inlocuit cu release-ul
Windows modern si nu verifica / instaleaza auto-update-uri.

Compatibilitate proiectata
---------------------------
- Windows XP SP3 x86
- Windows Server 2003 x86 (best effort)
- binar: windows/386
- toolchain obligatoriu pentru build XP: Go 1.10.8
- protocol central: 1
- schema inventar: 2.9
- port local: TCP/9078

De ce Go 1.10.8
---------------
Go 1.10.8 este ultima versiune Go cu suport pentru Windows XP / Server 2003.
Un binar compilat cu Go modern poate fi PE32/386, dar runtime-ul modern nu mai
este compatibil cu XP. De aceea build-xp.* refuza intentionat alt Go.

Ce colecteaza
-------------
- identitate: hostname, FQDN/domain, MachineGuid, UUID/serial/vendor/model prin
  Registry + WMIC cand este disponibil;
- retea: interfete/IP/MAC, rute/default gateway, DNS;
- storage: volume locale prin WMIC;
- hosts;
- servicii Windows;
- porturi listening prin netstat;
- conturi locale;
- software Desktop instalat din Registry;
- firewall XP (best effort);
- W32Time/NTP;
- detectie best-effort pentru IIS/Apache si servicii DB uzuale.

Sectiunile care nu exista pe XP (Docker, AppX/MSIX etc.) sunt trimise goale.
Erorile unui collector nu opresc agentul: inventarul devine partial/degraded.

Integrare vm-doc-server
-----------------------
Agentul foloseste acelasi protocol v1 ca agentul principal:
  POST /api/v1/agent-registration/register
  POST /api/v1/agent-registration/inventory
  POST /api/v1/agent-registration/heartbeat

Autentificarea catre server foloseste tokenul central de inregistrare ca Bearer.
Agentul expune local /health si endpointurile /v1/* necesare pentru colectare.

Build
-----
Pe Linux, dupa instalarea Go 1.10.8 in /opt/go1.10.8:
  ./build-xp.sh

Pe un host Windows cu Go 1.10.8:
  build-xp.cmd

Rezultatul trebuie sa fie:
  vm-doc-agent-xp-1.0.0-windows-386.exe

NU distribui pe XP binarul de smoke-test construit cu un Go modern.

Instalare
---------
Din CMD cu drepturi Administrator:

  vm-doc-agent-xp-1.0.0-windows-386.exe install --central-url http://SERVER:9080

Daca tokenul nu este dat in command line, installerul il cere interactiv.
Pentru deployment neinteractiv:

  vm-doc-agent-xp-1.0.0-windows-386.exe install ^
    --central-url http://SERVER:9080 ^
    --registration-token-file C:\Secure\vm-doc-registration-token.txt

Instalarea copiaza binarul in:
  %ProgramFiles%\VM-Doc\AgentXP\vm-doc-agent-xp.exe

Starea este pastrata in mod normal in:
  %ALLUSERSPROFILE%\Application Data\VM-Doc\AgentXP

Agentul ruleaza ca Scheduled Task "vm-doc-agent-xp", sub SYSTEM, la startup.
Auto-update este dezactivat intentionat.

Verificare
----------
  "C:\Program Files\VM-Doc\AgentXP\vm-doc-agent-xp.exe" status

sau:
  curl http://127.0.0.1:9078/health

Pe XP fara curl, se poate folosi browserul pentru:
  http://127.0.0.1:9078/health

Log:
  %ALLUSERSPROFILE%\Application Data\VM-Doc\AgentXP\vm-doc-agent-xp.log

Colectare manuala JSON in consola:
  "C:\Program Files\VM-Doc\AgentXP\vm-doc-agent-xp.exe" collect

Repair
------
Ruleaza din kitul aceleiasi versiuni:
  vm-doc-agent-xp-1.0.0-windows-386.exe repair --central-url http://SERVER:9080

Configuratia/tokenul existente sunt pastrate, iar Scheduled Task este recreat.

Uninstall
---------
  "C:\Program Files\VM-Doc\AgentXP\vm-doc-agent-xp.exe" uninstall

Pentru stergerea si a starii/configuratiei:
  "C:\Program Files\VM-Doc\AgentXP\vm-doc-agent-xp.exe" uninstall --purge

Securitate / limitari
---------------------
- ramura XP este legacy/frozen si trebuie folosita doar pe masinile care nu pot
  fi migrate;
- pentru retele izolate se poate folosi HTTP intern, exact ca agentii existenti;
- HTTPS depinde de capabilitatile TLS/certificate ale runtime-ului Go 1.10.8;
- nu exista auto-update; orice upgrade XP se face explicit;
- comenzile Registry/WMIC/netsh/netstat pot varia pe imagini XP foarte vechi sau
  customizate, de aceea colectarea este best-effort si nu omoara daemonul.
